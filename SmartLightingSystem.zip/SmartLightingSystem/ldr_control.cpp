#include "ldr_control.h"
#include "config.h"
#include <Adafruit_NeoPixel.h>
#include <Arduino.h>
#include <stdint.h>

// RGB values for LEDs
uint8_t r = 255, g = 10, b = 255;

// LED pin and strip configuration
Adafruit_NeoPixel ledStrip1 = Adafruit_NeoPixel(NUM_LEDS1, LED_PIN1, NEO_GRB + NEO_KHZ800);
Adafruit_NeoPixel ledStrip2 = Adafruit_NeoPixel(NUM_LEDS2, LED_PIN2, NEO_GRB + NEO_KHZ800);
Adafruit_NeoPixel lonelyLed = Adafruit_NeoPixel(1, LONELY_LED_PIN, NEO_GRB + NEO_KHZ800);

// Set color for a section of a strip
// void setRGBColor(Adafruit_NeoPixel& strip, int start, int end, uint8_t r, uint8_t g, uint8_t b) {
//   for (int i = start; i <= end ; i++) {
//     strip.setPixelColor(i, strip.Color(r, g, b));
//   }
// }

// Initialize all strips
void initLightStrips() {
  ledStrip1.begin(); ledStrip1.setBrightness(100); ledStrip1.show();
  ledStrip2.begin(); ledStrip2.setBrightness(100); ledStrip2.show();
  lonelyLed.begin(); lonelyLed.setBrightness(100); lonelyLed.show();
}

// Read LDRs and set zones accordingly
void checkAllLightSensors() {
  int ldr1 = analogRead(34);
  int ldr2 = analogRead(35);

  Serial.print("LDR1: "); Serial.print(ldr1);
  Serial.print(" | LDR2: "); Serial.println(ldr2);

  // Zone 0: ledStrip1 [0–7], LDR1
  if (ldr1 < LOW_LIGHT_THRESHOLD) {
    for (int i = 0; i < 8; i++) {
      ledStrip1.setPixelColor(i, ledStrip1.Color(0, 255, 0)); // R, G, B
    }
  } else {
    for (int i = 0; i < 8; i++) {
      ledStrip1.setPixelColor(i, ledStrip1.Color(0, 0, 0)); // R, G, B
    }
  }

  // Zone 1: ledStrip1 [8–16], LDR2
  if (ldr2 < LOW_LIGHT_THRESHOLD) {
    for (int i = 8; i < 16; i++) {
      ledStrip1.setPixelColor(i, ledStrip1.Color(0, 0, 255)); // R, G, B
    }
  } else {
    for (int i = 8; i < 16; i++) {
      ledStrip1.setPixelColor(i, ledStrip1.Color(0, 0, 0)); // R, G, B
    }
  }

  // Zone 2: ledStrip1 [17–23], LDR1
  if (ldr1 < LOW_LIGHT_THRESHOLD) {
    for (int i = 16; i < 24; i++) {
      ledStrip1.setPixelColor(i, ledStrip1.Color(255, 0, 0)); // R, G, B
    }
  } else {
    for (int i = 16; i < 24; i++) {
      ledStrip1.setPixelColor(i, ledStrip1.Color(0, 0, 0)); // R, G, B
    }
  }
  

  // Zone 3: ledStrip2 [0–7], LDR2
  if (ldr2 < LOW_LIGHT_THRESHOLD) {
    for (int i = 0; i < 8; i++) {
      ledStrip2.setPixelColor(i, ledStrip2.Color(r,g,b)); // R, G, B
    }
  } else {
    for (int i = 0; i < 8; i++) {
      ledStrip2.setPixelColor(i, ledStrip2.Color(0, 0, 0)); // R, G, B
    }
  }
  ledStrip1.show();
  ledStrip2.show();
}
