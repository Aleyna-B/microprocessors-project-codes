#ifndef LDR_CONTROL_H
#define LDR_CONTROL_H

void initLightStrips();
void checkAllLightSensors();

#endif