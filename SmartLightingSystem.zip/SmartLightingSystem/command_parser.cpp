#include "command_parser.h"

void parseCommand(String cmd) {
  cmd.trim();
  cmd.toLowerCase();

  // if (cmd == "mode:party") {
  //   setRGBColor(255,0,255);
  // } else if (cmd == "mode:movie") {
  //   setRGBColor(10,10,30);
  // } else if (cmd == "mode:dinner") {
  //   setRGBColor(255,250,50);
  // } else if (cmd.startsWith("color:")) {
  //   int r, g, b;
  //   sscanf(cmd.c_str(), "color:%d,%d,%d", &r, &g, &b);
  //   setRGBColor(r, g, b);  // Direct RGB control
  // }
}