#include "config.h"
#include "ldr_control.h"
#include "wifi_conn.h"
#include "bt_conn.h"
// #include "clock_module.h"

void setup() {
  Serial.begin(115200);
  Serial.println("Hello from setup!");
  //initMotionSensors();
  initLightStrips();
  //initWiFi();
  initBluetooth();
  // initRTC();
}

void loop() {
  // delay(1000);
  //checkAllMotionSensors();
  checkAllLightSensors();
  handleBluetooth();
  // updateTimeAndReport();
  //checkBackendForCommands();
  // delay(500);
}

