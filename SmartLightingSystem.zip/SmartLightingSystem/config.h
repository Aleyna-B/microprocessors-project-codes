#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>  // Needed for String type

inline String activeMode = "off";

// Pin configuration
#define NUM_PIR_SENSORS 2
#define NUM_LDR_SENSORS 2
#define NUM_LEDS1 24
#define NUM_LEDS2 8
#define NUM_ZONES 3
#define ZONE_SIZE 8

const int PIR_SENSOR_PINS[NUM_PIR_SENSORS] = {13, 15};
const int LDR_SENSOR_PINS[NUM_LDR_SENSORS] = {34, 35};

#define LED_PIN1       25
#define LED_PIN2       22
#define LONELY_LED_PIN 21

#define PIN_CLK  18 // RTC
#define PIN_DAT  19 // RTC
#define PIN_RST  4  // RTC

#define MINUTE 60000 // for converting milliseconds to a minute
#define SECOND 1000  // for converting milliseconds to a second

// Thresholds
#define LOW_LIGHT_THRESHOLD   3000  
#define LOWER_LIGHT_THRESHOLD 1800

// Wi-Fi & Flask
#define WIFI_SSID         "realme C25"
#define WIFI_PASSWORD     "5ytx4vxz"
#define FLASK_SERVER_URL  "http://192.168.136.124:5001/api/automations/trigger"

#endif // CONFIG_H