#include "clock_module.h"
#include "config.h"
#include "wifi_conn.h"

#include <ThreeWire.h>
#include <RtcDS1302.h>
#include <Adafruit_NeoPixel.h>

extern Adafruit_NeoPixel* ledStrips[];

ThreeWire myWire(PIN_DAT, PIN_CLK, PIN_RST);
RtcDS1302<ThreeWire> Rtc(myWire);

// Track last sent time
unsigned int lastReportTime = 0;
const unsigned int reportInterval = 30 * 60 * 1000; // 30 minutes

void initRTC() {
  Rtc.Begin();
  if (!Rtc.IsDateTimeValid()) {
    Serial.println("RTC not valid; setting to compile time.");
    Rtc.SetDateTime(RtcDateTime(__DATE__, __TIME__));
  }
}

void updateTimeAndReport() {
  unsigned long now = millis();
  if (now - lastReportTime < reportInterval) return;

  lastReportTime = now;

  RtcDateTime currentTime = Rtc.GetDateTime();
  char timeBuffer[6];
  sprintf(timeBuffer, "%02d:%02d", currentTime.Hour(), currentTime.Minute());

  extern String activeMode; // should be set when modes are changed
  String modeStatus = activeMode.length() > 0 ? activeMode : "off";

  // Determine active LED zones
  String activeStrips = "";

  if (modeStatus != "off") {
    // Add LED_PIN1 for all zones if in use
    activeStrips += String(LED_PIN1);

    // Add LED_PIN2 if its zone is active (controlled by LDR 35)
    activeStrips += "," + String(LED_PIN2);

    // Optionally include the lonely LED (pin 21) if used for indicator
    activeStrips += "," + String(LONELY_LED_PIN);
  } else {
    activeStrips = "off";
  }

  // Construct JSON-style message
  String message = "{";
  message += "\"time\":\"" + String(timeBuffer) + "\",";
  message += "\"mode\":\"" + modeStatus + "\",";
  message += "\"strips\":\"" + activeStrips + "\"";
  message += "}";

  //sendWebSocketMessage(message);
}
