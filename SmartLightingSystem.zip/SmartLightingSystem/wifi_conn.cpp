#include <WiFi.h>
#include <HTTPClient.h>
#include "config.h"
#include "command_parser.h"
#include "wifi_conn.h"

void initWiFi() {
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected");
}

// Function to send a message to the backend via HTTP POST
void sendHttpMessage(const String& msg) {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(FLASK_SERVER_URL);
    http.addHeader("Content-Type", "application/json");

    String json = "{\"message\": \"" + msg + "\"}";
    int httpResponseCode = http.POST(json);

    if (httpResponseCode > 0) {
      String response = http.getString();
      Serial.println("HTTP Response: " + response);
      parseCommand(response);  // Optionally parse backend response
    } else {
      Serial.print("Error on HTTP request: ");
      Serial.println(httpResponseCode);
    }
    http.end();
  } else {
    Serial.println("WiFi not connected");
  }
}

// Optional: HTTP polling for incoming commands (GET)
void checkBackendForCommands() {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(FLASK_SERVER_URL);
    int httpResponseCode = http.GET();

    if (httpResponseCode == 200) {
      String response = http.getString();
      Serial.println("Received from backend: " + response);
      parseCommand(response);  // Pass command to handler
    } else {
      Serial.print("GET failed, code: ");
      Serial.println(httpResponseCode);
    }

    http.end();
  }
}
