#ifndef WIFI_CONN_H
#define WIFI_CONN_H
#include <Arduino.h>

void initWiFi();
void sendHttpMessage(const String& msg);
void checkBackendForCommands();  // Optional polling

#endif
